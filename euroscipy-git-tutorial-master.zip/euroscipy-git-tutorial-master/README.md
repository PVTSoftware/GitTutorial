# euroscipy-git-tutorial
## Introduction to Version Control with Git

This repository contains material for an introductory tutorial on Git at EuroSciPy 2017.

Presently, this is work in progress.

A PDF file can be built from the LaTex source by

```
   lualatex presentation
```

To build the images from the sources in `images/src`, [PyX 0.14.1](https://pypi.python.org/pypi/PyX/0.14.1) was used.

#### Releases
##### [v2017](https://github.com/gertingold/euroscipy-git-tutorial/releases/tag/v2017)
Introductory tutorial given at EuroSciPy 2017 in Erlangen on August 29, 2017.
A video is available on [Youtube](https://www.youtube.com/watch?v=mkQzl2v7BuI).
